<?php
$page_title = 'Enroll';
include('header.html');
include('program.php');

session_start();
if($_SESSION["username"]) {
    echo "User: ".$_SESSION["username"].', Click here to <a href="logout.php" title="Logout">Logout</a>';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require('db_connect.php');
    $errors = array();
    // Get form data
   
    $member_id = $_SESSION["member_id"];
    $programName = $_POST["programName"];
    $instructor_id = (int)$_POST["instructor_id"];

    if ($programName == "Tiny Tigers") {
        $amount = 70.00;
        $payment_date = date("Y-m-d");
    } else if ($programName == "Little Ninjas") {
        $amount = 100.00;
        $payment_date = date("Y-m-d");
    } else if ($programName == "Junior") {
        $amount = 120.00;
        $payment_date = date("Y-m-d");
    } else if ($programName == "Defense and Tactical Training Program") {
        $amount = 140.00;
        $payment_date = date("Y-m-d");
    }

    
    // create new record for the Payments table, SELECT new payment ID
    $q2 = "INSERT INTO Payments (ID, Member_id, Payment_Date, Amount) VALUES (NULL, $member_id,'$payment_date',$amount);";
    $result = mysqli_query($database, $q2);

    // select the LAST record from the Payments table
    $sql_id = "SELECT MAX(ID) as max_id from Payments";
    $result2 = mysqli_query($database, $sql_id);
    $row = $result2->fetch_assoc();
    $payment_id = (int)$row['max_id'];

    // Insert data into MySQL table
    $qsql = "INSERT INTO Enrollments (ID, Member_Id, Payment_Id, ProgramName, Instructor_Id) VALUES (NULL, $member_id,$payment_id,'$programName',$instructor_id);";
    $result3 = mysqli_query($database, $qsql);

    
    if ($result && $result2 && $result3) {
      // If all queries were successful, redirect to confirmation page
      header('Location: confirmation.php');
      exit(); // Add exit() function here
  } else {
      // If there was an error, display error message
      echo "Error: " . mysqli_error($database);
  }
}
header('Location: confirmation.php');
exit();

include('footer.html');
?>
