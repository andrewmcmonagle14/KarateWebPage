<?php

session_start();

include('db_connect.php');
include('signin.php');

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
  
    $query = "SELECT * FROM Members WHERE Username = '$username' AND Password = '$password'";
    $result = mysqli_query($database, $query);
  
    if($username == "admin" && $password = "admin")
    {
        header("Location: systemadmin.php");
        exit();
    }

    if (mysqli_num_rows($result) == 1) {
      $row = mysqli_fetch_assoc($result);
      $_SESSION['member_id'] = $row['ID'];
      header('Location: login.php');
    } else {
      header('Location: signin.php?error=1');
    }
  } else {
    header('Location: signin.php');
  }
?>


