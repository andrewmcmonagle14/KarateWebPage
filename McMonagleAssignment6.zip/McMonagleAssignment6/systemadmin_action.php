<?php

session_start();
include 'db_connect.php';

if($_SERVER['REQUEST_METHOD'] == 'POST');
{
    
    if($_POST['delInstructor'])
    {
        
        $id = $_POST['instructorID'];
        $sql = "DELETE FROM Instructors WHERE ID='$id'";
        $result = $database->query($sql);
        
    }

    if($_POST['addInstructor'])
    {
        $name = $_POST['instructorName'];
        $sql = "INSERT INTO Instructors (instructorname) values ('$name')";
        $result = $database->query($sql);
        
    }

    if($_POST['delMember'])
    {
        
        $id = $_POST['memberID'];
        $sql = "DELETE FROM Members WHERE ID='$id'";
        $result = $database->query($sql);
        
    }

    if($_POST['addMember'])
    {
        $user = $_POST['memberUsername'];
        $first = $_POST['memberFName'];
        $last = $_POST['memberLName'];
        $phone = $_POST['memberPhone'];
        $pass = $_POST['memberPassword'];
        
        $sql = "INSERT INTO Members (Username, Last_Name, First_Name, Phone, Date_Joined, Password) values ('$user', '$last', '$first', '$phone', NOW(), '$pass')";
        $result = $database->query($sql);
        
    }

    if ($_POST['updateMember']) {
        $memberID = $_POST['memberID'];
        $newUser = $_POST['memberUsername'];
        $newFirstName = $_POST['memberFName'];
        $newLastName = $_POST['memberLName'];
        $newPhone = $_POST['memberPhone'];
        $newPassword = $_POST['memberPassword'];
    
        $updateMemberSql = "UPDATE Members SET Username = '$newUser', First_Name='$newFirstName', Last_Name='$newLastName', Phone='$newPhone', Password='$newPassword' WHERE ID=$memberID";
        $database->query($updateMemberSql);
    }
    

    header("Location: systemadmin.php");
        exit();
}



mysqli_close($database);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Update Member</title>
</head>
<body>
<?php
    include 'db_connect.php';
    // update member functionality
if (isset($_POST['updateMember'])) {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];

    // validate input
    if (!preg_match("/^[a-zA-Z0-9]+$/", $username)) {
        echo "<p>Username must contain only letters and numbers.</p>";
    } else if (!preg_match("/^[a-zA-Z]+$/", $first_name)) {
        echo "<p>First name must contain only letters.</p>";
    } else if (!preg_match("/^[a-zA-Z]+$/", $last_name)) {
        echo "<p>Last name must contain only letters.</p>";
    } else if (!preg_match("/^\d{10}$/", $phone)) {
        echo "<p>Phone number must be 10 digits.</p>";
    } else {
        $sql = "UPDATE Members SET Username='$username', First_Name='$first_name', Last_Name='$last_name', Phone='$phone' WHERE ID='$id'";
        if ($database->query($sql)) {
            echo "<p>Member updated successfully.</p>";
        } else {
            echo "<p>Error updating member: " . $database->error . "</p>";
        }
    }
}
?>
<form action="systemadmin_action.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $memberID; ?>">
    <label for="username">Username:</label><br> 
    <input type="text" id="username" name="username" value="<?php echo $username; ?>"><br>
    <label for="firstname">First Name:</label><br>
    <input type="text" id="firstname" name="firstname" value="<?php echo $firstname; ?>"><br>
    <label for="lastname">Last Name:</label><br>
    <input type="text" id="lastname" name="lastname" value="<?php echo $lastname; ?>"><br>
    <label for="phone">Phone:</label><br>
    <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>"><br><br>
    <input type="submit" name="updateMember" value="Update">
</form>
</body>
</html>
