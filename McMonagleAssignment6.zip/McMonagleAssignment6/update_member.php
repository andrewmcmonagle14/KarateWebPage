<?php
    session_start();
    include 'db_connect.php';

    // Get the member ID from the URL
    $id = $_GET['id'];

    // If the form was submitted, update the member record in the database
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $phone = $_POST['phone'];

        $sql = "UPDATE Members SET Username='$username', First_Name='$first_name', Last_Name='$last_name', Phone='$phone' WHERE ID=$id";
        $database->query($sql);

        header("Location: systemadmin.php");
        exit();
    }

    // Otherwise, display the update form
    $sql = "SELECT * FROM Members WHERE ID=$id";
    $result = $database->query($sql);
    $row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Member</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Update Member</h1>
        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" class="form-control" name="username" value="<?php echo $row['Username']; ?>">
            </div>
            <div class="form-group">
                <label>First Name</label>
                <input type="text" class="form-control" name="first_name" value="<?php echo $row['First_Name']; ?>">
            </div>
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" class="form-control" name="last_name" value="<?php echo $row['Last_Name']; ?>">
            </div>
            <div class="form-group">
                <label>Phone</label>
                <input type="text" class="form-control" name="phone" value="<?php echo $row['Phone']; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</body>
</html>
