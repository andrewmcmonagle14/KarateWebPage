<!DOCTYPE html>
<html lang="en">
<head>
    <title>Blue Karate Dojo | Home</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Header -->
    <header>
<?php include 'header.html'; ?>
</header>
    <!-- Main Content -->
    <div class="container my-5">
        <div class="row">
            <div class="col-md-6">
                <h1>Welcome to the Blue Karate Dojo!</h1>
                <p>We are a premier karate school with expert instructors and a welcoming community. Whether you're a beginner or an experienced martial artist, we have a program that will help you reach your goals.</p>
                <a href="signup.php" class="btn btn-primary mr-3">Sign Up</a>
                <a href="signin.php" class="btn btn-outline-primary">Sign In</a>
            </div>
            <div class="col-md-6"> 
                <img src="https://www.wildapricot.com/wp-content/uploads/2022/10/martial-arts-softwarebaaf820e5a9b4411be333073f6d87143.png" alt="myPic" width="900" height="850"/>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
  <?php include('footer.html'); ?>
</footer>

    <!-- Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
