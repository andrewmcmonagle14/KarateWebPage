<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
  <header>
<?php include 'header.html'; ?>
</header>
<div class="container mt-5">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<h2>Sign Up</h2>
		<form method="POST" action="signup_action.php">
		<div class="form-group">
			<label for="username">Username:</label>
			<input type="text" class="form-control" id="username" placeholder="Enter username" name="username" required>
			</div>
			<div class="form-group">
      		<label for="password">Password:</label>
			<input type="password" class="form-control" id="password" placeholder="Enter password" name="password" required>
			</div>
			<div class="form-group">
			<label for="first_name">First Name:</label>
			<input type="text" class="form-control" id="first_name" placeholder="Enter first name" name="first_name" required>
			</div>
			<div class="form-group">
			<label for="last_name">Last Name:</label>
			<input type="text" class="form-control" id="last_name" placeholder="Enter last name" name="last_name" required>
			</div>
			<div class="form-group">
			<label for="phone">Phone:</label>
			<input type="text" class="form-control" id="phone" placeholder="Enter phone number" name="phone" required>
			</div>
			<button type="submit" name="submit1" class="btn btn-primary">Sign Up</button>
		</form>
		</div>
	</div>
</div>

<footer>
  <?php include('footer.html'); ?>
</footer>

</body>
</html>
