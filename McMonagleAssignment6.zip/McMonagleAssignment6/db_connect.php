<?php

$servername = "rei.cs.ndsu.nodak.edu";
$username = "andrew_mcmonagle_371s23";
$password = "y1lXi1v2tN0!";
$db = "andrew_mcmonagle_db371s23";

$database = mysqli_connect($servername, $username, $password, $db);

if (mysqli_connect_errno()) {
   die("Connect failed: %s\n" + mysqli_connect_error());
   exit();
} 
else{echo "Connected successfully";

}

?>
