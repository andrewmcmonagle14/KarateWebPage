<!DOCTYPE html>
<html>
<head>
    <title>Admin</title>
    <!-- Bootstrap CSS -->
    <<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .column {
            float: right;
            width: 50%;
            padding: 10px;
        }
        .button {
            margin-top: 10px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            text-align: left;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<?php
# Set page title and display header section.
$page_title = 'Admin' ;
include ( 'header.html' ) ;
    session_start();
    include 'db_connect.php';
    echo "Welcome Admin!" . 'Click here to <a href="logout.php" title="Logout">Logout</a>';
    echo '<br />';
    echo "<div class='column'>";
    echo('Instructor List: <br />');
    echo "<table>";
    echo "<tr>";
    echo "<th> ID </th>";
    echo "<th> Instructor </th>";
    echo "</tr>";
    
    $sql = "SELECT * FROM Instructors";
    $result = $database->query($sql);
    while($row = $result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $row['ID'] . "</td>";
        echo "<td>" . $row['InstructorName'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "<form action='systemadmin_action.php' method='post'>";
    echo "<input type='text' name='instructorID'/>";
    echo "<input type='submit' name='delInstructor' class='button' value='Delete by ID' />";
    echo "</form>";
    echo "<form action='systemadmin_action.php' method='post'>";
    echo "<input type='text' name='instructorName'/>";
    echo "<input type='submit' name='addInstructor' class='button' value='Add by Name' />";
    echo "</form>";
    echo "</div>";

    #column 2
    echo "<div class='column'>";
    echo "Member List: <br />";
    echo "<table>";
    echo "<tr>";
    echo "<th> ID </th>";
    echo "<th> User Name </th>";
    echo "<th> First Name </th>";
    echo "<th> Last Name </th>";
    echo "<th> Phone </th>";
    echo "<th> Date Joined </th>";
    echo "</tr>";

    $sql = "SELECT * FROM Members";
    $result = $database->query($sql);
    while($row = $result->fetch_assoc()){
        echo "<tr>";
        echo "<td>" . $row['ID'] . "</td>";
        echo "<td>" . $row['Username'] . "</td>";
        echo "<td>" . $row['First_Name'] . "</td>";
        echo "<td>" . $row['Last_Name'] . "</td>";
        echo "<td>" . $row['Phone'] . "</td>";
        echo "<td>" . $row['Date_Joined'] . "</td>";
        echo "<td><a href='update_member.php?id=" . $row['ID'] . "'>Update</a></td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "<form action='systemadmin_action.php' method='post'>";
    echo "<input type='text' name='memberID'/>";
    echo "<input type='submit' name='delMember' class='button' value='Delete by ID' />";
    echo "</form>";
    echo "<br /><br />";
    echo "<form action='systemadmin_action.php' method='post'>";
    echo "<h5>Search Members by Last Name or ID</h5>";
    echo "<p>Last Name: </p><input type='text' name='searchLastName'/>";
    echo "<input type='submit' name='searchMemberLN' class='button' value='Search by Last Name' />";
    echo "<p>ID: </p><input type='text' name='searchID'/>";
    echo "<input type='submit' name='searchMemberID' class='button' value='Search by ID' />";
    echo "</form>";
    echo "<form action='systemadmin_action.php' method='post'>";
    echo "<h5>Add new Member</h5>";
    echo "<p>User Name: </p><input type='text' name='memberUsername'/>";
    echo "<p>First Name: </p><input type='text' name='memberFName'/>";
    echo "<p>Last Name: </p><input type='text' name='memberLName'/>";
    echo "<p>Phone: </p><input type='text' name='memberPhone'/>";
    echo "<p>Password: </p><input type='text' name='memberPassword'/>";
    echo "<input type='submit' name='addMember' class='button' value='Add Member' />";
    echo "</form>";
    echo "</div>";

    echo "</div>";
    
    

    
?>
    <footer>
  <?php include('footer.html'); ?>
</footer>
</body>
</html>