<?php
// Start session
session_start();

// Include database connection
include("db_connect.php");
include("signup.php");

if(isset($_POST['submit1'])) {
    $username = $_POST['username'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    $query = "INSERT INTO Members (Username, First_Name, Last_Name, Phone, Date_Joined, Password) VALUES ('$username', '$first_name', '$last_name', '$phone', NOW(), '$password')";
    $result = mysqli_query($database, $query);

    if($result) {
        header("Location: signin.php");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($database);
    }
}
mysqli_close($database);
?>
