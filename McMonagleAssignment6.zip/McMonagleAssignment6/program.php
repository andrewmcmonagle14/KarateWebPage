<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Enroll</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </head>

<body>
<header>
<?php include ('header.html'); ?>
</header>
<?php
   session_start();
   if($_SESSION["username"])
    {
        echo ("<div class='container'><div class='row'><div class='col-sm-6'><h3>User: ".$_SESSION["username"]."</h3></div><div class='col-sm-6 text-right'><a class='btn btn-primary' href='logout.php' title='Logout'>Logout</a></div></div></div>");
    }
?>
 <div class="container mt-5">
        <div>
            <h2>Enroll For:</h2>
        </div>
  <br>
   <form action="register_action.php"  method="post">
      <div class="form-group">
          <input type="radio" class="form-check-input" name="programName" value="Tiny Tigers" id="tinyTigers" />
          <label for="tinyTigers">The Tiny Tigers Program focuses on exposing 2 and 3yr old's to a classroom setting and helping them begin learning the basic motor skills, listening, and focus skills. ($70.00)</label>
      </div>
      <div class="form-group">
          <input type="radio" class="form-check-input" name="programName" value="Little Ninjas" id="littleNinjas" />
          <label for="littleNinjas">The Little Ninjas Program focuses on 4 - 10yr old's. Program in improving basic motor skills, listening, and focus skills. ($100.00)</label>
      </div>
      <div class="form-group">
          <input type="radio" class="form-check-input" name="programName" value="Junior" id="junior" />
          <label for="junior">The Junior Program focuses on 11 - 16yr old's. Program system is designed with the new student in mind, educating them from Beginner to Advanced Technician over the life of the training. ($120.00)</label>
      </div>
      <div class="form-group">
          <input type="radio" class="form-check-input" name="programName" value="Defense and Tactical Training Program" id="dot" />
          <label for="dot">The Defense and Tactical Training Program focused on educating individuals. ($140.00)</label>
      </div>
      <br>
      <div class="form-group">
          <label for="instructors">Select Instructors</label>
          <select id="instructors" name="instructor_id" class="form-control" style="width: 175px;">
            <option value=1>Neo</option>
            <option value=2>Mr Miyagi</option>
            <option value=3>Jason Bourne</option>
            <option value=4>Master Splinter</option>
          </select>
      </div>
      <br>
        <div class="form-group">
            <input id="Submit3" type="submit" class="btn btn-primary" value="Enroll">
        </div>
        <p><a href="logout.php">Log Out</a></p>
    </form>
</div>

    <?php include('footer.html'); ?>
</body>
</html>