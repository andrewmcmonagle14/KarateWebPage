<?php

session_start();

include 'db_connect.php';


if (!isset($_SESSION['member_id'])) {
  header('Location: signin.php');
  exit();
}

$member_id = $_SESSION['member_id'];

$query = "SELECT First_Name, Last_Name, Phone, Date_Joined FROM Members WHERE ID = '$member_id'";

$result = mysqli_query($database, $query);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $first_name = $row['First_Name'];
  $last_name = $row['Last_Name'];
  $phone_number = $row['Phone'];
  $date_joined = $row['Date_Joined'];
} else {
  echo "Error: Invalid member ID.";
  exit();
}

$query = "SELECT ID, Amount, Payment_Date FROM Payments WHERE member_id = '$member_id' ORDER BY Payment_Date DESC";

$result = mysqli_query($database, $query);

$payments = array();

while ($row = mysqli_fetch_assoc($result)) {
  $payments[] = $row;
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<header>
<?php include 'header.html'; ?>
</header>
<div class="container mt-5">
  <div class="row">
    <div class="col-md-6 offset-md-3">
      <h2>Welcome <?php echo $first_name . " " . $last_name; ?></h2>
      <p>Phone Number: <?php echo $phone_number; ?></p>
      <p>Date Joined: <?php echo $date_joined; ?></p>
      <hr>
      <h3>Payments</h3>
      <table class="table">
        <thead>
          <tr>
            <th>Payment ID</th>
            <th>Amount</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($payments as $payment) { ?>
            <tr>
              <td><?php echo $payment['ID']; ?></td>
              <td><?php echo $payment['Amount']; ?></td>
              <td><?php echo $payment['Payment_Date']; ?></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
      <a href="program.php">Register for a Program Now!</a>
      <p><a href="logout.php">Log Out</a></p>
    </div>
  </div>
</div>
<footer>
  <?php include('footer.html'); ?>
</footer>
</body>
</html>

